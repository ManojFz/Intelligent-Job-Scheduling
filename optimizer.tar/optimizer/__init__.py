"""Route optimization package."""
